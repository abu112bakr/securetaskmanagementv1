package com.example.securetaskmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuretaskmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
